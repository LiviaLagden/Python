numero = int(input())
if numero < 2:
    print("Não é primo")
else:
    e_primo = True
    for i in range(2, int(numero**0.5) + 1):
        if numero % i == 0:
            e_primo = False
            break
    if e_primo:
        print("É primo")
    else:
        print("Não é primo")
