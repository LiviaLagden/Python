soma = 0
while True:
    num = float(input())
    if num == 0:
        break
    soma += num
print(soma)
