q = int(input())
if q > 0:
    a, b = 0, 1
    termo = 0
    while termo < q:
        print(a)
        a, b = b, a + b
        termo += 1
