while True:
    nota = float(input())
    if 0 <= nota <= 10:
        print("Nota válida!")
        break
    print("Nota inválida!")
