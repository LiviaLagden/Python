qtd_alunos = int(input())
notas = []
for _ in range(qtd_alunos):
    nota = float(input())
    notas.append(nota)
media = sum(notas) / len(notas)
print(media)